<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stripe extends CI_Controller {

	public function __construct() 
	{
		parent::__construct();	
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->library('email');
		$this->load->library('user_agent');
		$this->load->helper('directory');
		$this->load->helper('security');
		$this->load->model('Home_model');
		
		}
	public function index()
	{	
		
		$header['c_url']=base_url('stripe');
		$header['meta_title']='stripe payment';
		$header['meta_description']='stripe payment';
		$header['meta_keywords']='stripe payment';
		$header['scroll_data']=$this->Home_model->get_scrolling_content();
		$this->load->view('html/header',$header);
		$data['article_list']=$this->Home_model->get_article_list();
		$data['lastest_updates_list']=$this->Home_model->get_latest_updates();
		$data['browse_by_subjects']=$this->Home_model->get_browse_by_subjects();
		$data['journals_list']=$this->Home_model->get_journals_list();
		$this->load->view('html/stripe',$data);
		$this->load->view('html/footer');
		
	}
	public  function post(){
		$post=$this->input->post();
		$ad=array(
		'title'=>isset($post['title'])?$post['title']:'',
		'firstName'=>isset($post['firstName'])?$post['firstName']:'',
		'lastName'=>isset($post['lastName'])?$post['lastName']:'',
		'regcompany'=>isset($post['regcompany'])?$post['regcompany']:'',
		'city'=>isset($post['city'])?$post['city']:'',
		'state'=>isset($post['state'])?$post['state']:'',
		'country'=>isset($post['country'])?$post['country']:'',
		'email'=>isset($post['email'])?$post['email']:'',
		'phone'=>isset($post['phone'])?$post['phone']:'',
		'address'=>isset($post['address'])?$post['address']:'',
		'address'=>isset($post['address'])?$post['address']:'',
		'journel'=>isset($post['journel'])?$post['journel']:'',
		'total_amount'=>isset($post['total_amount'])?$post['total_amount']:'',
		'created_at'=>date('Y-m-d H:i:s'),
		);
				
		$save=$this->Home_model->save_stripe_details($ad);
		if($save){
			//$this->session->set_flashdata('success',"Your Data is saved was successfully sent.");
			redirect('stripepaymentcontroller/index/'.base64_encode($save));
		}else{
			$this->session->set_flashdata('error',"technical problem will occurred. Please try again.");
			redirect('stripe');
		}
	}
	
	
}
