<?php
defined('BASEPATH') OR exit('No direct script access allowed');
   
class StripePaymentController extends CI_Controller {
    
    public function __construct() {
       parent::__construct();
       $this->load->library("session");
       $this->load->helper('url');
	   $this->load->model('Home_model');
    }
    
    public function index()
    {
		$header['c_url']=base_url('stripepaymentcontroller/index');
		$header['meta_title']='Stripe Payment Gateway';
		$header['meta_description']='Stripe Payment Gateway';
		$header['meta_keywords']='Stripe Payment Gateway';
		
		$sid=base64_decode($this->uri->segment(3));
		$header['scroll_data']=$this->Home_model->get_scrolling_content();
		$d['p_d']=$this->Home_model->get_stripe_details($sid);
		//echo '<pre>';print_r($d);exit;
		$this->load->view('html/header',$header);
		$this->load->view('html/checkout',$d);
		$this->load->view('html/footer');
    }
    
    public function handlePayment()
    {
        
		$post=$this->input->post();
		//echo '<pre>';print_r($post);exit;
		$p_d=$this->Home_model->get_stripe_details($post['jid']);		
		$ud=array(
			'paid_amt'=>isset($post['amount'])?$post['amount']:'',
			'stripeToken'=>isset($post['stripeToken'])?$post['stripeToken']:'',
			'stripeTokenType'=>isset($post['stripeTokenType'])?$post['stripeTokenType']:'',
			'updated_at'=>date('Y-m-d H:i:s'),
		 );
		$this->Home_model->update_stripe_details($p_d['s_p_id'],$ud);
        $this->session->set_flashdata('success', 'Thanks for your Payment. out team reach out soon.');             
        redirect('/stripe', 'refresh');
    }
}