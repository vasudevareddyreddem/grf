  <style>
  .html-tabs li {
	  display:block;
	  float:none;
	  border-bottom:1px solid #fff;
	  margin:20px 0px;
	  background:#ddd;
  } 
  .html-tabs li > a {

	  border:0px;
  }
  .my-20{
	  margin:20px 0px;
  }
  </style>
		<div class="container " >
            <div class="row">
				<div class="col-md-12">
					<br>
					<h3 class=""> Article   
						<span class="text-success"> Mini Review </span> 
					</h3>
					<div class="text-primary h4">Lorem Ipsum is simply dummy text of the printing 
					</div>
					<div >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
					</div>
					<div >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
					</div>
					<div >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
					</div>
					
				
				</div>
				<div class="clearfix">&nbsp;</div>
				<div class="col-md-12 thumbnail">
					<div class=" col-md-3">
							<ul class="nav nav-tabs html-tabs">
								<li class="active"><a href="#tab1primary" data-toggle="tab">Abstract</a></li>
								<li><a href="#tab2primary" data-toggle="tab"> Article</a></li>
								<li><a href="#tab3primary" data-toggle="tab"> Figures</a></li>
								<li><a href="#tab4primary" data-toggle="tab">Tables</a></li>
								<li><a href="#tab5primary" data-toggle="tab">References</a></li>
								<li><a href="#tab6primary" data-toggle="tab">Suggested Citation</a></li>
								
							</ul>
					</div>
					<div class="col-md-9">
					<div class="panel-body">
						<div class="tab-content">
							<div class="tab-pane fade in active" id="tab1primary">
							 <div class=" Welcome_txt fadeInLeft wow animated  " data-wow-duration="1000ms" data-wow-delay="1000ms">
                  
					<br>
					<h3 class="">1 .  Abstract </h3>
					
					<p >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					</p>
					<br>	
					<h3 class="">2 .Keywords </h3>
					
					<p >Lorem Ipsum  ,Lorem Ipsum ,Lorem Ipsum ,Lorem Ipsum ,Lorem Ipsum ,Lorem Ipsum ,
					</p>
					<br>
					
					
                   
                </div>
							
							</div>
							<div class="tab-pane fade" id="tab2primary">
							<div class=" Welcome_txt fadeInLeft wow animated  " data-wow-duration="1000ms" data-wow-delay="1000ms">
								<div class="row">
           
										<br>
					<h3 class="text-success">1 . Introduction </h3>
					
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					</p>
					<br>	
					<h3 class="">1.1.  Case Presentation </h3>
					
					<p >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					</p>
					<br>
					<h3 class="">2.Discussion</h3>
					
					<p >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					</p>
					<p >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					</p>
					<p >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					</p>
					<p >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					</p>
					<br>
					<h4>Non-pharmacological therapy conveyed to her were on the following:</h4>
					<div>
						<ul>
							<li>Lorem Ipsum is simply dummy</li>
							<li>Lorem Ipsum is simply dummy</li>
							<li>Lorem Ipsum is simply dummy</li>
							<li>Lorem Ipsum is simply dummy</li>
							<li>Lorem Ipsum is simply dummy</li>
							<li>Lorem Ipsum is simply dummy</li>
							<li>Lorem Ipsum is simply dummy</li>
							<li>Lorem Ipsum is simply dummy</li>
							<li>Lorem Ipsum is simply dummy</li>
							<li>Lorem Ipsum is simply dummy</li>
							<li>Lorem Ipsum is simply dummy</li>
						</ul>
					</div>
					<br>
					<h3 class="">2.Conclusion</h3>
					
					<p >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					</p>

								</div>
							</div>
							</div>
							<div class="tab-pane fade" id="tab3primary">
				<div class="">
					<div class="row">
					<br>
								<h3 class="">Figures</h3>
					</div>
					
					<div class="row">
						
						<div class="col-md-4">
							<img  class="img-responsive" src="https://www.researchgate.net/profile/Masaki_Fujioka/publication/232743479/figure/fig3/AS:300504916742188@1448657364024/A-The-photograph-shows-a-necrotic-wound-of-toes-1-3-in-a-patient-receiving-HD-because_Q320.jpg" alt="images" >
						</div>
						<div class="col-md-4">
							<img  class="img-responsive" src="https://www.researchgate.net/profile/Masaki_Fujioka/publication/232743479/figure/fig3/AS:300504916742188@1448657364024/A-The-photograph-shows-a-necrotic-wound-of-toes-1-3-in-a-patient-receiving-HD-because_Q320.jpg" alt="images" >
						</div>
						<div class="col-md-4">
							<img  class="img-responsive" src="https://www.researchgate.net/profile/Masaki_Fujioka/publication/232743479/figure/fig3/AS:300504916742188@1448657364024/A-The-photograph-shows-a-necrotic-wound-of-toes-1-3-in-a-patient-receiving-HD-because_Q320.jpg" alt="images" >
						</div>
						<div class="clearfix"> &nbsp;</div>
						<p class="text-center">text for images </p>
					</div>
				</div>
				
							
							</div>
							<div class="tab-pane fade" id="tab4primary">
							<br>
										<h3 class="">Tables</h3>
							
							
								<table class="table table-bordered">
									<tr class="bg_color text-white">
										<th class="text-center">Diagnostic parameters</th>
										<th class="text-center">Patient value</th>
										<th class="text-center">Normal values</th>
										<th class="text-center">Inference</th>
									</tr>
									<tr>
										<td>White Blood Cells</td>
										<td>2230 mg/dl</td>
										<td>4000-11000 mg/dl</td>
										<td>Inference</td>
									</tr>
									<tr>
										<td>White Blood Cells</td>
										<td>2230 mg/dl</td>
										<td>4000-11000 mg/dl</td>
										<td>Inference</td>
									</tr>
									<tr>
										<td>White Blood Cells</td>
										<td>2230 mg/dl</td>
										<td>4000-11000 mg/dl</td>
										<td>Inference</td>
									</tr>
									<tr>
										<td>White Blood Cells</td>
										<td>2230 mg/dl</td>
										<td>4000-11000 mg/dl</td>
										<td>Inference</td>
									</tr>
									<tr>
										<td>White Blood Cells</td>
										<td>2230 mg/dl</td>
										<td>4000-11000 mg/dl</td>
										<td>Inference</td>
									</tr>
								</table>
							
							</div>
							<div class="tab-pane fade" id="tab5primary">
								<div class="row">
								<br>
										<h3 class="">References</h3>
										<ol>
										<a href="" ><li class="my-20"> Lacci MK, Dardik A (2010) Platelet-rich plasma: Support for its use in wound healing. Yale J Biol Med 83: 1-9.</li></a>
										<a href="" ><li class="my-20"> Lacci MK, Dardik A (2010) Platelet-rich plasma: Support for its use in wound healing. Yale J Biol Med 83: 1-9.</li></a>
										<a href="" ><li class="my-20"> Lacci MK, Dardik A (2010) Platelet-rich plasma: Support for its use in wound healing. Yale J Biol Med 83: 1-9.</li></a>
										<a href="" ><li class="my-20"> Lacci MK, Dardik A (2010) Platelet-rich plasma: Support for its use in wound healing. Yale J Biol Med 83: 1-9.</li></a>
										<a href="" ><li class="my-20"> Lacci MK, Dardik A (2010) Platelet-rich plasma: Support for its use in wound healing. Yale J Biol Med 83: 1-9.</li></a>
										<a href="" ><li class="my-20"> Lacci MK, Dardik A (2010) Platelet-rich plasma: Support for its use in wound healing. Yale J Biol Med 83: 1-9.</li></a>
									</ol>
								</div>
							</div>
							<div class="tab-pane fade" id="tab6primary">
								<br>
								<h3 class="">Citation</h3>
					
					<p >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
					</p><br>
							
							</div>
							
						</div>
					</div>
				</div>
				</div>
				
		</div>
				
			</div>
		</div>
       
